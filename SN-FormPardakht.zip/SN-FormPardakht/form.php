<div class="form">
	<form method="post">
		<table width="100%">
			<tr>
				<td>نام یا نام خانوادگی</td>
				<td>
					<input type="text" name="family" value="<?php if (isset($_POST['family'])) echo ($_POST['family']); ?>"/>
					<span class="require">*</span>
				</td>
			</tr>

			<tr>
				<td>ادرس پست الکترونیک</td>
				<td>
					<input type="text" name="email" dir="ltr" value="<?php if (isset($_POST['email'])) echo ($_POST['email']); ?>"/>
					<span class="require">*</span>
				</td>
			</tr>

			<tr>
				<td>شماره تماس</td>
				<td>
					<input type="text" name="mobile" dir="ltr" value="<?php if (isset($_POST['mobile'])) echo ($_POST['mobile']); ?>" />
					<span class="require">*</span>
				</td>
			</tr>

			<tr>
				<td>مبلغ پرداختی</td>
				<td>
					<input type="text" name="price" dir="ltr" value="<?php if (isset($_POST['price'])) echo ($_POST['price']); ?>" />
					<span class="require">*</span>
					<br /><span class="tip">به تومان</span>
				</td>
			</tr>

			<tr>
				<td>توضیحات</td>
				<td>
					<textarea name="description"><?php if (isset($_POST['description'])) echo ($_POST['description']); ?></textarea>
				</td>
			</tr>

			<tr>
				<td>
				</td>
				<td>
					<input type="submit" name="pay" value="پرداخت" />
				</td>
			</tr>
		</table>
	</form>
</div>