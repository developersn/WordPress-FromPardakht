﻿<div class="wrap">
	<h3>تاریخچه پرداخت ها و سفارشات</h3>
	<?php
	global $wpdb;
	$wpdb->query("CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."sn_form` (
     `id` int(11) NOT NULL AUTO_INCREMENT,
     `name` varchar(100) COLLATE utf8_persian_ci NOT NULL DEFAULT '',
     `email` varchar(100) COLLATE utf8_persian_ci NOT NULL DEFAULT '',
     `mobile` varchar(15) COLLATE utf8_persian_ci NOT NULL DEFAULT '',
     `price` int(11) NOT NULL,
     `description` text COLLATE utf8_persian_ci NOT NULL,
     `ResNum` varchar(50) COLLATE utf8_persian_ci NOT NULL,
     `RefNum` varchar(50) COLLATE utf8_persian_ci NOT NULL DEFAULT '',
     `Status` varchar(50) COLLATE utf8_persian_ci NOT NULL DEFAULT 'Pending',
     PRIMARY KEY (`id`)
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ;");
	if (isset($_REQUEST['do']) && isset($_REQUEST['id']) && $_REQUEST['do']=='delete')
	{
		$wpdb->query("delete from `".$wpdb->prefix."sn_form` where `id`=".$_REQUEST['id']);
		echo('<script>document.location="admin.php?page=sn_form/history.php";</script>');
	}
	$q = $wpdb->get_results("select * from `".$wpdb->prefix."sn_form` order by id desc");
	?>
	<table class="widefat post fixed" cellspacing="0">
	<?php wp_nonce_field('update-options');?>
	<thead>
	<tr>    
	<th width="15%">نام</th>
	<th width="15%">ایمیل</th>
	<th width="10%">موبایل</th>
	<th width="20%">توضیحات</th>
	<th width="9%">مبلغ (به تومان)</th>
	<th width="10%">شماره سفارش</th>
	<th width="10%">شماره پیگیری</th>
	<th width="8%">وضعیت</th>
	<th width="5%">حذف</th>
	</tr>
	</thead>
	<tbody>
	<?php foreach($q as $row){
	echo '<tr>';	
	echo '<th>'.$row->name.'</th>';
	echo '<th>'.$row->email.'</th>';
	echo '<th>'.$row->mobile.'</th>';
	echo '<th>'.$row->description.'</th>';
	echo '<th>'.$row->price.'</th>';
	echo '<th>'.$row->ResNum.'</th>';
	echo '<th>'.$row->RefNum.'</th>';
	echo '<th>'.$row->Status.'</th>';
	echo '<th><a href="http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'] . '&do=delete&id='.$row->id.'">حذف</a></th>';
	echo '</tr>'; }	?>
	</tbody>
	</table>
</div>