﻿<?php
/*
Plugin Name: فرم پرداخت آنلاين
Plugin URI: http://#
Description: با اين افزونه فرم پرداخت با مبلغ دلخواه ايجاد مي شود.از کد [sn_form] در برگه استفاده نماييد
Version: 1.0
*/
session_start();
function sn_form_menu()
{
	if (function_exists('add_options_page'))
	{
		$capability = 10;
		add_menu_page   ('فرم درگاه پرداخت', 'فرم درگاه پرداخت', $capability, 'sn_form/setting.php', 'sn_form_setting', plugin_dir_url( __FILE__ ).'sn_form.png');
		add_submenu_page('sn_form/setting.php', 'تنظیمات درگاه', 'تنظیمات درگاه', $capability, 'sn_form/setting.php', 'sn_form_setting');
		add_submenu_page('sn_form/setting.php', 'تاریخچه تراکنش ها', 'تاریخچه تراکنش ها', $capability, 'sn_form/history.php', 'sn_form_history');
	}
}
add_action('admin_menu', 'sn_form_menu');

function sn_form_setting()
{
	if (!current_user_can('manage_options'))
	{
		wp_die('You do not have sufficient permissions to access this page.');
	}
	settings_fields('sn_form_options');
	function register_sn_form()
	{
		register_setting('sn_form_options', 'api');
		register_setting('sn_form_options', 'webservice');
	}

	require_once('setting.php');
}

function sn_form_history()
{
	if (!current_user_can('manage_options'))
	{
		wp_die('You do not have sufficient permissions to access this page.');
	}
	require_once('history.php');
}

function sn_form()
{
	global $wpdb;
	if(isset($_POST['pay'])&&$_POST['pay'])
	{
		if($_POST['family']&&$_POST['email']&&$_POST['mobile']&&$_POST['price'])
		{
			srand();
			// Security
			@session_start();
			$sec = uniqid();
			$md = md5($sec.'vm');
			// Security
			$name        = $_POST['family'];
			$email       = $_POST['email'];
			$mobile      = $_POST['mobile'];
			$price       = (int)$_POST['price'] * 1;
			$description = $_POST['description'];
			$ResNum      = rand(1000000,99999999);
			$sep         = parse_url($_SERVER['REQUEST_URI'],PHP_URL_QUERY)==NULL?'?':'&';
			$callBackURL = 'http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'].$sep."do=verify&ResNum=".$ResNum."&md=".$md."&sec=".$sec;
			$Description = $description;
			$Paymenter =  $name;
			$Email = $email ;
			$Mobile =  $mobile;


			if ($price<100)
			{
				echo '<p class="error">مبلغ وارد شده معتبر نیست. حداقل مبلغ پرداختی 100 تومان می باشد.</p>';
				require_once('form.php');
				return;
			}
			$wpdb->query("CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."sn_form` (
			  `id` int(11) NOT NULL AUTO_INCREMENT,
			  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL DEFAULT '',
			  `email` varchar(100) COLLATE utf8_persian_ci NOT NULL DEFAULT '',
			  `mobile` varchar(15) COLLATE utf8_persian_ci NOT NULL DEFAULT '',
			  `price` int(11) NOT NULL,
			  `description` text COLLATE utf8_persian_ci NOT NULL,
			  `ResNum` varchar(50) COLLATE utf8_persian_ci NOT NULL,
			  `RefNum` varchar(50) COLLATE utf8_persian_ci NOT NULL DEFAULT '',
			  `Status` varchar(50) COLLATE utf8_persian_ci NOT NULL DEFAULT 'Pending',
			  PRIMARY KEY (`id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ;");


                     $WebService= get_option('webservice');
					if ($WebService == 1){
						    
				    if($Email==''){$Email='0'; }
				     if($Paymenter==''){$Paymenter='0';}
				      if($Mobile==''){$Mobile='0';}
				       if($Description==''){$Description='0';}
				       $api= get_option('api');
					   	$data_string = json_encode(array(
					'pin'=> $api,
					'price'=> $price,
					'callback'=>$callBackURL,
					'order_id'=> $ResNum,
					'email'=> $Email,
					'description'=> $Description,
					'name'=> $Paymenter,
					'mobile'=> $Mobile,
					'ip'=> $_SERVER['REMOTE_ADDR'],
					'callback_type'=>2
					));
				    
			        }
					else
					{
					$api= get_option('api');
					   	$data_string = json_encode(array(
					'pin'=> $api,
					'price'=> $price,
					'callback'=>$callBackURL,
					'order_id'=> $ResNum,
					'email'=> '0',
					'description'=> $Description,
					'name'=> '0',
					'mobile'=> '0',
					'ip'=> $_SERVER['REMOTE_ADDR'],
					'callback_type'=>2
					));
					    
					}


					$ch = curl_init('https://developerapi.net/api/v1/request');
					curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($ch, CURLOPT_HTTPHEADER, array(
					'Content-Type: application/json',
					'Content-Length: ' . strlen($data_string))
					);
					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
					curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
					$result = curl_exec($ch);
					curl_close($ch);


					$json = json_decode($result,true);			
								$res=$json['result'];
	                 switch ($res) {
						    case -1:
						    $msg = "پارامترهای ارسالی برای متد مورد نظر ناقص یا خالی هستند . پارمترهای اجباری باید ارسال گردد";
						    break;
						     case -2:
						    $msg = "دسترسی api برای شما مسدود است";
						    break;
						     case -6:
						    $msg = "عدم توانایی اتصال به گیت وی بانک از سمت وبسرویس";
						    break;
						     case -9:
						    $msg = "خطای ناشناخته";
						    break;
						     case -20:
						    $msg = "پین نامعتبر";
						    break;
						     case -21:
						    $msg = "ip نامعتبر";
						    break;
						     case -22:
						    $msg = "مبلغ وارد شده کمتر از حداقل مجاز میباشد";
						    break;
						    case -23:
						    $msg = "مبلغ وارد شده بیشتر از حداکثر مبلغ مجاز هست";
						    break;
						      case -24:
						    $msg = "مبلغ وارد شده نامعتبر";
						    break;
						      case -26:
						    $msg = "درگاه غیرفعال است";
						    break;
						      case -27:
						    $msg = "آی پی مسدود شده است";
						    break;
						      case -28:
						    $msg = "آدرس کال بک نامعتبر است ، احتمال مغایرت با آدرس ثبت شده";
						    break;
						      case -29:
						    $msg = "آدرس کال بک خالی یا نامعتبر است";
						    break;
						      case -30:
						    $msg = "چنین تراکنشی یافت نشد";
						    break;
						      case -31:
						    $msg = "تراکنش ناموفق است";
						    break;
						      case -32:
						    $msg = "مغایرت مبالغ اعلام شده با مبلغ تراکنش";
						    break;
						      case -35:
						    $msg = "شناسه فاکتور اعلامی order_id نامعتبر است";
						    break;
						      case -36:
						    $msg = "پارامترهای برگشتی بانک bank_return نامعتبر است";
						    break;
						        case -38:
						    $msg = "تراکنش برای چندمین بار وریفای شده است";
						    break;
						      case -39:
						    $msg = "تراکنش در حال انجام است";
						    break;
                            case 1:
						    $msg = "پرداخت با موفقیت انجام گردید.";
						    break;
						    default:
						       $msg = "خطایی در اتصال رخ داده است : ".$josn['result'];
						}
			if(!empty($json['result']) AND $json['result'] == 1)
			{
				// Set Session
				/*$_SESSION[$sec] = [
					'price'=>$amount ,
					'order_id'=>$invoice_id ,
					'au'=>$json['au'] ,
				];*/

				$_SESSION['au'] = $json['au']; //SET AU Session
                $_SESSION['price'] =$amount ; 
                $_SESSION['order_id'] =$invoice_id;





				$wpdb->query("insert into `".$wpdb->prefix."sn_form` (`name`,`email`,`mobile`,`price`,`description`,`ResNum`,`RefNum`) values ('$name','$email','$mobile','$price','$description','$ResNum','".$json['au']."')");
				echo ("<div style='display:none'>".$json['form']."</div>Please wait ... <script language='javascript'>document.payment.submit(); </script>");
			}
			else
			{
				echo '<p class="error">'.$msg.'</p>';
				require_once('form.php');
			}
		}
		else
		{
			echo '<p class="error">خطا : تکمیل تمامی فیلد ها الزامی می باشد.</p>';
			require_once('form.php');
		}
		return;
	}
	elseif (isset($_REQUEST['do'])&&$_REQUEST['do']=='verify')
	{
		
		if(!empty($_GET['sec']) or !empty($_GET['md']))
		{
		
		$ResNum = $_GET['ResNum'];
		$qay    = $wpdb->get_results("select * from `".$wpdb->prefix."sn_form` where `ResNum`='$ResNum'");
		$pay    = $qay[0];
		$au     = $pay->RefNum;
		$price  = $pay->price;
		$name   = $pay->name;
		$email  = $pay->email;
		$mobile = $pay->mobile;
			// Security
			$sec=$_GET['sec'];
			$mdback = md5($sec.'vm');
			$mdurl=$_GET['md'];
			// Security
					
		if($mdback == $mdurl)
	{
		//$transData = $_SESSION[$sec];
		//$au=$transData['au']; //

		$amount = $_SESSION['price']; //
        $au=$_SESSION['au']; //
        $invoice_id=$_SESSION['order_id'];

		
			$bank_return = $_POST + $_GET ;
			$data_string = json_encode(array (
			'pin' => get_option('api'),
			'price' => $price,
			'order_id' => $ResNum,
			'au' => $au,
			'bank_return' =>$bank_return,
			));

			$ch = curl_init('https://developerapi.net/api/v1/verify');
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Content-Length: ' . strlen($data_string))
			);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
			$result = curl_exec($ch);
			curl_close($ch);
			$json = json_decode($result,true);	
										$res=$json['result'];
	                 switch ($res) {
						    case -1:
						    $msg = "پارامترهای ارسالی برای متد مورد نظر ناقص یا خالی هستند . پارمترهای اجباری باید ارسال گردد";
						    break;
						     case -2:
						    $msg = "دسترسی api برای شما مسدود است";
						    break;
						     case -6:
						    $msg = "عدم توانایی اتصال به گیت وی بانک از سمت وبسرویس";
						    break;
						     case -9:
						    $msg = "خطای ناشناخته";
						    break;
						     case -20:
						    $msg = "پین نامعتبر";
						    break;
						     case -21:
						    $msg = "ip نامعتبر";
						    break;
						     case -22:
						    $msg = "مبلغ وارد شده کمتر از حداقل مجاز میباشد";
						    break;
						    case -23:
						    $msg = "مبلغ وارد شده بیشتر از حداکثر مبلغ مجاز هست";
						    break;
						      case -24:
						    $msg = "مبلغ وارد شده نامعتبر";
						    break;
						      case -26:
						    $msg = "درگاه غیرفعال است";
						    break;
						      case -27:
						    $msg = "آی پی مسدود شده است";
						    break;
						      case -28:
						    $msg = "آدرس کال بک نامعتبر است ، احتمال مغایرت با آدرس ثبت شده";
						    break;
						      case -29:
						    $msg = "آدرس کال بک خالی یا نامعتبر است";
						    break;
						      case -30:
						    $msg = "چنین تراکنشی یافت نشد";
						    break;
						      case -31:
						    $msg = "تراکنش ناموفق است";
						    break;
						      case -32:
						    $msg = "مغایرت مبالغ اعلام شده با مبلغ تراکنش";
						    break;
						      case -35:
						    $msg = "شناسه فاکتور اعلامی order_id نامعتبر است";
						    break;
						      case -36:
						    $msg = "پارامترهای برگشتی بانک bank_return نامعتبر است";
						    break;
						        case -38:
						    $msg = "تراکنش برای چندمین بار وریفای شده است";
						    break;
						      case -39:
						    $msg = "تراکنش در حال انجام است";
						    break;
                            case 1:
						    $msg = "پرداخت با موفقیت انجام گردید.";
						    break;
						    default:
						       $msg = $josn['msg'];
						}
		if($json['result']==1)
		{
			$wpdb->query("update `".$wpdb->prefix."sn_form` set `RefNum`='$au' , `Status`='Completed' where `ResNum`='$ResNum'");
			echo '<p class="success">پرداخت با موفقیت تکمیل شد. <br /> شماره پیگیری : '.$au.' <br /> شماره سفارش : '.$ResNum.'</p>';
			$mail_headers = "Content-Type: text/plain; charset=utf-8\r\nFrom: ".get_option('admin_email')." <".get_option('admin_email').">\r\nX-Mailer: PHP/".phpversion()."\r\n";
			wp_mail($pay->email, "پرداخت شما تایید شد", "پرداخت شما تایید شد \r\n شماره پیگیری : $au \r\n شماره سفارش : $ResNum", $mail_headers);
		}
		else
		{
			$wpdb->query("update `".$wpdb->prefix."sn_form` set `RefNum`='$au' , `Status`='error ".$msg."' where `ResNum`='$ResNum'");
			echo '<p class="error">نتیجه استعلام پرداخت شما نا معتبر می باشد. پرداخت لغو شد : </p>'.$msg;
		}
		}
		else
		{
			$wpdb->query("update `".$wpdb->prefix."sn_form` set `RefNum`='$au' , `Status`='Security Error' where `ResNum`='$ResNum'");
			echo '<p class="error">خطای امنیتی !!!! . پرداخت لغو شد</p>';
		}
		}
		else
		{
			$wpdb->query("update `".$wpdb->prefix."sn_form` set `RefNum`='$au' , `Status`='Security Error' where `ResNum`='$ResNum'");
			echo '<p class="error">خطای امنیتی !!!! . پرداخت لغو شد</p>';
		}
	}
	else
	{
		require_once('form.php');
	}
}

add_shortcode('sn_form', 'sn_form');

?>